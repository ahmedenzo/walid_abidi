package com.controller;


import com.model.Mytable;
import com.service.MytableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/tables")
public class MytableController {

    @Autowired
    private MytableService mytableService;

    @GetMapping
    public String listTables(Model model) {
        model.addAttribute("tables", mytableService.getAllTables());
        return "tables/list";
    }

    @GetMapping("/new")
    public String showTableForm(Model model) {
        model.addAttribute("mytable", new Mytable());
        return "tables/form";
    }

    @PostMapping
    public String saveTable(@ModelAttribute Mytable mytable) {
        mytableService.saveTable(mytable);
        return "redirect:/tables";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        mytableService.getTableById(id).ifPresent(mytable -> model.addAttribute("mytable", mytable));
        return "tables/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteTable(@PathVariable Integer id) {
        mytableService.deleteTable(id);
        return "redirect:/tables";
    }
}